<?php
    include '../conecta.php';
?>



<?php 

$codlivro = $_GET['codlivro'];


$titulo = $_POST['titulo'];
$autor= $_POST['autor'];
$genero= $_POST['genero'];
$editora= $_POST['editora'];
$pag= $_POST['pag'];
$quantexe= $_POST['quantexe'];


$consulta = $conexao -> prepare ("
	UPDATE livros SET 
	titulo='$titulo', 
	autor='$autor',
	genero='$genero',
	editora='$editora',
	pag='$pag',
	quantexe='$quantexe'
	WHERE codlivro = '$codlivro'");

	$consulta -> execute();


	header('Location: form_update_livro.php');

?>