<?php 

	include '../conecta.php';

	$titulo=$_POST['titulo'];
	$autor=$_POST['autor'];
	$editora=$_POST['editora'];
	$pag=$_POST['pag'];
	$genero=$_POST['select'];

	$consulta=$conexao -> prepare("INSERT INTO livros(titulo,autor,editora,pag,genero) VALUES ('$titulo','$autor','$editora','$pag','$genero')");

	$consulta -> execute();

	header('Location: index.php');






 ?>
