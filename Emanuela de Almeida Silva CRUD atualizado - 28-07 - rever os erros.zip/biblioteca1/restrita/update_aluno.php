<?php
    include '../conecta.php';
?>



<?php 

$ra = $_GET['codcli'];


$nome = $_POST['nome'];
$email= $_POST['email'];
$telefone= $_POST['telefone'];
$nascimento= $_POST['datanasc'];


$consulta = $conexao -> prepare ("
	UPDATE cliente SET 
	nome='$nome', 
	email='$email',
	datanasc='$nascimento',
	telefone='$telefone'
	WHERE codcli = '$ra'");

	$consulta -> execute();


	header('Location: form_update_aluno.php');

?>