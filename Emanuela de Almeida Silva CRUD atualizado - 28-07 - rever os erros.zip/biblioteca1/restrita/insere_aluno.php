<?php

	include '../conecta.php';
	$nome = $_POST['nome'];
	$email = $_POST['email'];
	$telefone = $_POST['telefone'];
	$nascimento = $_POST['datanasc'];
	$turma = $_POST['select'];

	$consulta = $conexao -> prepare("INSERT INTO cliente(nome,email,telefone,datanasc,turma) VALUES ('$nome','$email','$telefone','$datanasc','$turma')");

	$consulta -> execute();

	header('Location: index.php');
  ?>

