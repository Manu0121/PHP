<?php 

	$host = "localhost";
	$usuario ="root";
	$senha ="";
	$banco = "biblioteca";

	$conexao = new mysqli("$host","$usuario","$senha","$banco");

 ?>


