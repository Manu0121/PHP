-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 29-Jul-2020 às 01:00
-- Versão do servidor: 10.4.11-MariaDB
-- versão do PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `biblioteca`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `bibliotecario`
--

CREATE TABLE `bibliotecario` (
  `codbibli` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `datanasc` date DEFAULT NULL,
  `cpf` varchar(255) DEFAULT NULL,
  `rg` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telefone` int(11) DEFAULT NULL,
  `rua` varchar(255) DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `bairro` varchar(255) DEFAULT NULL,
  `cidade` varchar(255) DEFAULT NULL,
  `uf` char(2) DEFAULT NULL,
  `cep` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `bibliotecario`
--

INSERT INTO `bibliotecario` (`codbibli`, `nome`, `datanasc`, `cpf`, `rg`, `email`, `telefone`, `rua`, `num`, `bairro`, `cidade`, `uf`, `cep`) VALUES
(1, 'Emanuela', '0000-00-00', '010.101.110-23', '12.235.656-1', 'emanuela@gmail.com', 922226422, NULL, NULL, NULL, 'Mauá', 'SP', NULL),
(2, 'Maria', '0000-00-00', '373.223.363-13', '14.584.436-4', 'maria@gmail.com', 955526855, NULL, NULL, NULL, 'Mauá', 'SP', NULL),
(3, 'Ignes', '0000-00-00', '656.685.576-06', '97.587.157-7', 'ignes@gmail.com', 977777777, NULL, NULL, NULL, 'Mauá', 'SP', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `codcli` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `datanasc` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telefone` int(11) DEFAULT NULL,
  `turma` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`codcli`, `nome`, `datanasc`, `email`, `telefone`, `turma`) VALUES
(1, 'Jake Peralta', '0000-00-00', 'jake@gmail.com', 988884568, 'Formado'),
(2, 'Matteo Balsano', '0000-00-00', 'matteo@gmail.com', 923219999, '1 semestre Direito'),
(3, 'Katherine Sheffield', '0000-00-00', 'kate@gmail.com', 911589111, '3 semestre Direito'),
(4, 'Clara Basset', '0000-00-00', 'clara@gmail.com', 922035922, '3 EM'),
(5, 'Marcos Turner', '0000-00-00', 'marcos@gmail.com', 912345678, '3 EM'),
(6, 'Sybilla Bridgerton', '0000-00-00', 'billie@gmail.com', 990123456, '1 semestre Sociologia'),
(7, 'Amy Santiago', '0000-00-00', 'amy@gmail.com', 978901234, 'Formado'),
(8, 'Juliette Ferrars', '0000-00-00', 'juli@gmail.com', 945678901, '3 EM'),
(9, 'Ian Clarke', '0000-00-00', 'ian@gmail.com', 923456789, '1 semestre Relações Internacionais'),
(10, 'Robert Carroway', '0000-00-00', 'bit@gmail.com', 901234567, '2 semestre Administração'),
(11, 'Sofia Alonzo', '0000-00-00', 'sofie@gmail.com', 989012345, '1 semestre Ciência da Computação');

-- --------------------------------------------------------

--
-- Estrutura da tabela `empredev`
--

CREATE TABLE `empredev` (
  `codd` int(11) NOT NULL,
  `datadev` date DEFAULT NULL,
  `dataemp` date DEFAULT NULL,
  `codlivro` int(11) DEFAULT NULL,
  `codbibli` int(11) DEFAULT NULL,
  `codcli` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `empredev`
--

INSERT INTO `empredev` (`codd`, `datadev`, `dataemp`, `codlivro`, `codbibli`, `codcli`) VALUES
(1, '0000-00-00', '0000-00-00', 15, 3, 6),
(2, '0000-00-00', '0000-00-00', 2, 1, 10),
(3, '0000-00-00', '0000-00-00', 6, 2, 3),
(4, '0000-00-00', '0000-00-00', 1, 1, 1),
(5, '0000-00-00', '0000-00-00', 18, 3, 7),
(6, '0000-00-00', '0000-00-00', 10, 2, 5),
(7, '0000-00-00', '0000-00-00', 25, 2, 3),
(8, '0000-00-00', '0000-00-00', 22, 1, 8),
(9, '0000-00-00', '0000-00-00', 27, 3, 4),
(10, '0000-00-00', '0000-00-00', 18, 1, 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `livro`
--

CREATE TABLE `livro` (
  `codlivro` int(11) NOT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `autor` varchar(255) DEFAULT NULL,
  `genero` varchar(255) DEFAULT NULL,
  `editora` varchar(255) DEFAULT NULL,
  `pag` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `livro`
--

INSERT INTO `livro` (`codlivro`, `titulo`, `autor`, `genero`, `editora`, `pag`) VALUES
(1, 'Mar de Tinta e Ouro: A Leitora', 'Trac Chee', 'Fantasia', 'Plataforma 21', '457'),
(2, 'Os Miseráveis', 'Victor Hugo', 'Romance', 'Martin Claret', '1511'),
(3, 'Uma Dobra no Tempo', 'Madeleine LEngle', 'Fantasia', 'Harper Collins', '240'),
(4, 'A Megera Domada', 'William Shakespeare', 'Romance', 'Scipione', '150'),
(5, 'Estilhaça-me', 'Tahereh Mafi', 'Fantasia Distópica', 'Universo dos Livros', '352'),
(6, 'Destrua-me', 'Tahereh Mafi', 'Fantasia Distópica', 'Universo dos Livros', '125'),
(7, 'Capitães da Areia', 'Jorge Amado', 'Romance', 'Companhia de Bolso', '280'),
(8, 'Como Salvar Um Herói', 'Suzana Enoch', 'Romance', 'Harlequin', '294'),
(9, 'Perdida', 'Carina Rissi', 'Romance de Época', 'Verus', '364'),
(10, 'Harry Potter e a Pedra Filosofal', 'JK Rowling', 'Fantasia', 'Rocco', '208'),
(11, 'Percy Jackson e o Ladrão de Raios', 'Rick Riordan', 'Aventura', 'Intrínseca', '364'),
(12, 'O visconde que Me Amava', 'Julia Quinn', 'Romance de Época', 'Arqueiro', '304'),
(13, 'Corte de Espinhos e Rosas', 'Sarah J. Maas', 'Fantasia', 'Galera', '434'),
(14, 'Uma Dama Fora dos Padrões', 'Julia Quinn', 'Romance de Época', 'Arqueiro', '272'),
(15, 'A Poção Secreta', 'Amy Alward', 'Fantasia', 'Jangada', '368'),
(16, 'Wicked', 'Gregory Maguire', 'Fantasia', 'Leya', '496'),
(17, 'O Corcunda de Notre Dame', 'Victor Hugo', 'Romance', 'Zahar', '496'),
(18, 'Orgulho e Preconceito', 'Jane Austen', 'Romance de Época', 'Martin Claret', '424'),
(19, 'Caçadores de Trolls', 'Guillermo Del Toro', 'Aventura', 'Intrínseca', '340'),
(20, 'Como Treinar o Seu Dragão', 'Cressida Cowell', 'Aventura', 'Intrínseca', '222'),
(21, 'Os Segredos de Colin Bridgerton', 'Julia Quinn', 'Romance de Época', 'Arqueiro', '336'),
(22, 'A Seleção', 'Kiera Cass', 'Romance', 'Seguinte', '368'),
(23, 'Anne de Green Gables', 'Lucy Mauad Montgomery', 'Romance de Época', 'Coerência', '332'),
(24, 'Guardiões do Sangue', 'Carter Roy', 'Aventura', 'Rocco', '272'),
(25, 'Fazendo Meu Filme', 'Paula Pimenta', 'Romance', 'Gutenberg', '336'),
(26, 'O Acordo', 'Elle Kenedy', 'Romance', 'Paralela', '360'),
(27, 'Trono de Vidro', 'Sarah J. Maas', 'Fantasia', 'Galera', '392'),
(28, 'Procura-se Um Marido', 'Carina Rissi', 'Romance', 'Verus', '476'),
(29, 'Mentira Perfeita', 'Carina Rissi', 'Romance', 'Verus', '462'),
(30, 'Namorado de Aluguel', 'Kasie West', 'Romance', 'Verus', '252');

-- --------------------------------------------------------

--
-- Estrutura da tabela `livros`
--

CREATE TABLE `livros` (
  `codlivro` int(11) NOT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `autor` varchar(255) DEFAULT NULL,
  `genero` varchar(255) DEFAULT NULL,
  `editora` varchar(255) DEFAULT NULL,
  `quantexe` varchar(255) DEFAULT NULL,
  `pag` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `livros`
--

INSERT INTO `livros` (`codlivro`, `titulo`, `autor`, `genero`, `editora`, `quantexe`, `pag`) VALUES
(1, 'Mar de Tinta e Ouro: A Leitora', 'Trac Chee', 'Fantasia', 'Plataforma 21', '1', '457'),
(2, 'Os Miseráveis', 'Victor Hugo', 'Romance', 'Martin Claret', '6', '1511'),
(3, 'Uma Dobra no Tempo', 'Madeleine LEngle', 'Fantasia', 'Harper Collins', '3', '240'),
(4, 'A Megera Domada', 'William Shakespeare', 'Romance', 'Scipione', '2', '150'),
(5, 'Estilhaça-me', 'Tahereh Mafi', 'Fantasia Distópica', 'Universo dos Livros', '1', '352'),
(6, 'Destrua-me', 'Tahereh Mafi', 'Fantasia Distópica', 'Universo dos Livros', '5', '125'),
(7, 'Capitães da Areia', 'Jorge Amado', 'Romance', 'Companhia de Bolso', '9', '280'),
(8, 'Como Salvar Um Herói', 'Suzana Enoch', 'Romance', 'Harlequin', '5', '294'),
(9, 'Perdida', 'Carina Rissi', 'Romance de Época', 'Verus', '4', '364'),
(10, 'Harry Potter e a Pedra Filosofal', 'JK Rowling', 'Fantasia', 'Rocco', '7', '208'),
(11, 'Percy Jackson e o Ladrão de Raios', 'Rick Riordan', 'Aventura', 'Intrínseca', '5', '364'),
(12, 'O visconde que Me Amava', 'Julia Quinn', 'Romance de Época', 'Arqueiro', '2', '304'),
(13, 'Corte de Espinhos e Rosas', 'Sarah J. Maas', 'Fantasia', 'Galera', '1', '434'),
(14, 'Uma Dama Fora dos Padrões', 'Julia Quinn', 'Romance de Época', 'Arqueiro', '3', '272'),
(15, 'A Poção Secreta', 'Amy Alward', 'Fantasia', 'Jangada', '2', '368'),
(16, 'Wicked', 'Gregory Maguire', 'Fantasia', 'Leya', '1', '496'),
(17, 'O Corcunda de Notre Dame', 'Victor Hugo', 'Romance', 'Zahar', '1', '496'),
(18, 'Orgulho e Preconceito', 'Jane Austen', 'Romance de Época', 'Martin Claret', '1', '424'),
(19, 'Caçadores de Trolls', 'Guillermo Del Toro', 'Aventura', 'Intrínseca', '5', '340'),
(20, 'Como Treinar o Seu Dragão', 'Cressida Cowell', 'Aventura', 'Intrínseca', '3', '222'),
(21, 'Os Segredos de Colin Bridgerton', 'Julia Quinn', 'Romance de Época', 'Arqueiro', '5', '336'),
(22, 'A Seleção', 'Kiera Cass', 'Romance', 'Seguinte', '2', '368'),
(23, 'Anne de Green Gables', 'Lucy Mauad Montgomery', 'Romance de Época', 'Coerência', '3', '332'),
(24, 'Guardiões do Sangue', 'Carter Roy', 'Aventura', 'Rocco', '2', '272'),
(25, 'Fazendo Meu Filme', 'Paula Pimenta', 'Romance', 'Gutenberg', '1', '336'),
(26, 'O Acordo', 'Elle Kenedy', 'Romance', 'Paralela', '1', '360'),
(27, 'Trono de Vidro', 'Sarah J. Maas', 'Fantasia', 'Galera', '3', '392'),
(28, 'Procura-se Um Marido', 'Carina Rissi', 'Romance', 'Verus', '5', '476'),
(29, 'Mentira Perfeita', 'Carina Rissi', 'Romance', 'Verus', '3', '462'),
(30, 'Namorado de Aluguel', 'Kasie West', 'Romance', 'Verus', '1', '252');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id`, `nome`, `email`, `senha`) VALUES
(1, 'Emanuela', 'manu@gmail.com', '1234'),
(2, 'Maria', 'maria@gmail.com', '5678');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `bibliotecario`
--
ALTER TABLE `bibliotecario`
  ADD PRIMARY KEY (`codbibli`),
  ADD UNIQUE KEY `cpf` (`cpf`),
  ADD UNIQUE KEY `rg` (`rg`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`codcli`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices para tabela `empredev`
--
ALTER TABLE `empredev`
  ADD PRIMARY KEY (`codd`),
  ADD KEY `codlivro` (`codlivro`),
  ADD KEY `codbibli` (`codbibli`),
  ADD KEY `codcli` (`codcli`);

--
-- Índices para tabela `livro`
--
ALTER TABLE `livro`
  ADD PRIMARY KEY (`codlivro`);

--
-- Índices para tabela `livros`
--
ALTER TABLE `livros`
  ADD PRIMARY KEY (`codlivro`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `bibliotecario`
--
ALTER TABLE `bibliotecario`
  MODIFY `codbibli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `codcli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `empredev`
--
ALTER TABLE `empredev`
  MODIFY `codd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `livro`
--
ALTER TABLE `livro`
  MODIFY `codlivro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de tabela `livros`
--
ALTER TABLE `livros`
  MODIFY `codlivro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `empredev`
--
ALTER TABLE `empredev`
  ADD CONSTRAINT `empredev_ibfk_1` FOREIGN KEY (`codlivro`) REFERENCES `livro` (`codlivro`),
  ADD CONSTRAINT `empredev_ibfk_2` FOREIGN KEY (`codbibli`) REFERENCES `bibliotecario` (`codbibli`),
  ADD CONSTRAINT `empredev_ibfk_3` FOREIGN KEY (`codcli`) REFERENCES `cliente` (`codcli`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
